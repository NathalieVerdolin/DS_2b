﻿using System;
using MySql.Data.MySqlClient;

string conexao =
    "Server=maglev.proxy.rlwy.net;Port=13954;Database=railway;Uid=root;Pwd=TUqEGEKpmiBRDvIsPzoHXkIrsPQkvkIY";

using (MySqlConnection conn = new MySqlConnection(conexao))
{
    try
    {
        conn.Open();
        Console.WriteLine("Conectou ao banco de dados!");
    }
    catch (Exception msg)
    {
        Console.WriteLine("ERRO:" + msg);
    }
}